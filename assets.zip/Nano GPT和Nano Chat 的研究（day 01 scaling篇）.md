# 模型参数的规模大小和预训练的数据规模大小（scaling篇）

+ 参考论文链接
+ Scaling Law[2001.08361](https://arxiv.org/pdf/2001.08361)
+ Chinchila Scalinghttps://arxiv.org/abs/2203.15556)
+ 参考视频链接：[大模型进化论07: 深度拆解 Scaling Law | 为什么“大力出奇迹”是科学而非运气？| OpenAI 凭什么敢豪赌？_哔哩哔哩_bilibili](https://www.bilibili.com/video/BV17SF8zhE4n/?spm_id_from=333.337.search-card.all.click&vd_source=f7571e599a30c72f84f9e7e1a7210a6f)

核心的观点：在训练的范式当中，模型的参数量的大小和训练的计算量以及训练数据集的大小存在幂等关系。



## Scaling Law

论文前提：作者是一个物理学家，用了物理学的一些研究直觉写的这篇文章。

+ 模型参数量（N）
+ 训练数据量（D）
+ 训练计算量（C）

### 1. 独立幂律现象：

+ 当固定上面变量中的一个，其它两个无限时，textloss（损失）就会在对数坐标轴中呈现线性关系。这种现象在物理学中意味着：

+ 相变现象：物理学中水到达0度会结冰，100度会蒸发。训练过程呈现类似物理系统的临界行为，会突然开智（我理解的是如此）。
+ 尺度无关性：就是规律和模型的参数量大小没有关系，小模型推导的内容可以应用到大模型当中。
+ 普适性：物理学中宏观量不依赖于微观结构。

![1772630421164](assets/1772630421164.png)

### 2. 结构无关性

实验发现：

- 不同 Transformer 结构
- 不同深宽比例
- 不同优化器

均满足相似幂律形式

这说明：Scaling 规律对架构细节并不敏感。

![1772631911329](assets/1772631911329.png)

### 3. 模型参数量的条件性

+ Embedding 参数通常不计入有效模型规模
+ 有效参数主要指参与计算与梯度更新的 Transformer block 参数

![1772631975219](assets/1772631975219.png)

### 4. 泛化能力的必然性

随着计算规模增加：

- 训练损失下降
- 验证损失同步下降

说明泛化能力在一定区间内随规模单调改善。

![1772632023804](assets/1772632023804.png)



### 5. 动态批大小

+ 在预训练过程中：

  - 初期应使用较小 batch size
  - 随 loss 降低逐步增加 batch size

  存在一个“临界 batch size”，超过后收益递减。

![1772632473416](assets/1772632473416.png)



### 6. 大小模型博弈

经验现象：

- 训练更大的模型较短时间
- 往往优于训练小模型更长时间

Loss 可以分解为：

L(N, T) = L_N(N) + L_T(T)

两部分近似解耦。

+ 下面函数左边代表的是损失值，右边是参数量大小和训练步数，他们是求和的关系，解耦的，对loss互不干扰

![1772632619804](assets/1772632619804.png)

+ 下面是模型的参数量大小和训练资源的大小，他们呈现U形状，表名我们应该训练一个大模型少些时间也比训练小模型很长时间好。

![1772632556483](assets/1772632556483.png)

+ 下图展示的是训练部署和模型参数的关系，结论是同样步数，模型越大，Loss越低。

![1772633053691](assets/1772633053691.png)

## Chinchilla Scaling（Compute-Optimal Training）

核心论文提出一个关键修正：

> 之前的大模型普遍“训练不足”（undertrained）。

#### 1. 关键发现

在固定 C 下：

$$C = 6ND$$

目标：最小化

$$L(N,D) = aN^{-\alpha} + bD^{-\beta}$$

加入约束 D = C/(6N)，代入得：

$$L(N) = aN^{-\alpha} + b\left(\frac{C}{6N}\right)^{-\beta}$$

对 N 求导并令其为 0，可得：

$$N \propto C^{1/2}, \quad D \propto C^{1/2}$$

即：

> 计算最优状态下，模型参数与训练 token 数应同阶增长。

#### 2. Compute 公式

训练计算量近似为：

C ≈ 6 N D

在固定 C 条件下求最优：

N ∝ C^{1/2}
D ∝ C^{1/2}

这意味着：

- 最优状态下模型和数据应同阶增长
- 不是单纯扩大参数

##### 若参数翻倍，token 也应翻倍。

经验比例：

$$D \approx 20N$$

该经验来自 Chinchilla 实验拟合结果。

从最优解比例可写为：

$$\frac{D}{N} = k$$

实验拟合得到：

$$k \approx 20$$

理论解释：

泛化误差近似分解为：

$$\text{Error} = \text{Bias}(N) + \text{Variance}(D)$$

当：

$$\text{Bias} \sim N^{-\alpha}$$
$$\text{Variance} \sim D^{-\beta}$$

平衡两项数量级：

$$N^{-\alpha} \sim D^{-\beta}$$

得到：

$$D \sim N^{\alpha/\beta}$$

实验中：

$$\alpha \approx \beta$$

因此：

$$D \propto N$$

常数项由真实数据拟合确定，约为 20。

这意味着：

- 1B 参数模型需要约 20B token
- 10B 参数模型需要约 200B token

否则模型处于高方差区，泛化受限。

#### 3. 与 Kaplan Scaling 的区别

Kaplan 结论：

- 更倾向于使用更大的模型
- 数据量增长相对缓慢

Chinchilla 修正：

- 很多模型参数过大但数据不足
- 应该缩小模型，增加数据

#### 4. MoE 架构下的 Scaling 推导

MoE（Mixture of Experts）中：

- 总参数量：N_total
- 激活参数量：N_active

每个 token 仅激活部分专家。

1. 计算量

$$C_{MoE} \approx 6 N_{active} D$$

而非 6 N_total D。

###### 2. Compute-optimal 条件

固定计算预算：

$$C = 6 N_{active} D$$

最优条件仍满足：

$$D \propto N_{active}$$

而不是 N_total。

###### 3. 关键差异

Dense 模型：

$$N = N_{total} = N_{active}$$

MoE 模型：

$$N_{total} \gg N_{active}$$

因此：

- 泛化由 N_total 决定
- 计算约束由 N_active 决定

若：

$$N_{total} = E \cdot N_{expert}$$

且每 token 激活 k 个专家：

$$N_{active} = k N_{expert}$$

则：

$$D \propto k N_{expert}$$

这说明：

MoE 可以在相同计算量下获得更高的表示容量，但数据需求仍与激活参数成比例。

---

#### 5. 实验对比意义

例如：

- 280B 参数模型训练数据较少
- 70B 参数模型训练更多数据

后者在相同计算预算下性能更优。

本质原因：

- 大模型若数据不足，会处于“高方差区”
- 泛化能力未被充分激活

#### 6. 工程启示

对于实际训练：

- 不要盲目堆参数
- 计算预算优先分配给 token 数量
- 数据清洗质量比模型盲目放大更重要

#### 7. 对 NanoGPT / NanoChat 的启示

在小规模实验环境下：

- 若算力有限，应优先保证 token 数量
- 模型规模选择应满足 N 与 D 同阶
- 训练步数不足时，大模型会严重欠拟合

可以推导一个实践原则：

> 在个人或中小规模算力环境下，优先做“充分训练的小模型”，而非“未收敛的大模型”。

------

# 四、总结

Scaling Law 告诉我们：

- Loss 与 N、D、C 存在幂律关系

Chinchilla 告诉我们：

- 在固定计算预算下
- 存在一个严格的最优 N 与 D 配比

二者结合形成现代大模型训练的基础理论框架。

这为 NanoGPT / NanoChat 的实验提供了理论指导：

- 规模选择
- 数据收集策略
- 训练预算分配

+ Scaling Law 给出幂律规律。

+ Chinchilla 给出 compute-optimal 训练策略。

+ 20 token / 参数 是实验拟合的最优比例。

+ MoE 下 scaling 应基于激活参数量推导。

+ 这些规律构成 NanoGPT / NanoChat 数据收集与模型规模设计的理论基础。

后续可进一步研究：

- MoE 架构下的 compute-optimal 规律
- 推理阶段 scaling
- 量化后的 scaling 行为